public class Main {

    public static void main(String[] args) {

        Warehouse warehouse = new Warehouse(5, 5);

        warehouse.addItem(0, 0,
                new GridItem("I101", "Laptop", 10));

        warehouse.addItem(1, 2,
                new GridItem("I102", "Phone", 25));

        warehouse.addItem(3, 4,
                new GridItem("I103", "Printer", 5));

        warehouse.displayGrid();

        System.out.println("\nSearching for item ID: I102");
        warehouse.searchItem("I102");

        System.out.println("\nSearching for item ID: I999");
        warehouse.searchItem("I999");
    }
}