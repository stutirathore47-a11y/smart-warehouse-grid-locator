public class Warehouse {

    private GridItem[][] grid;
    private int rows;
    private int cols;

    public Warehouse(int rows, int cols) {
        this.rows = rows;
        this.cols = cols;
        grid = new GridItem[rows][cols];
    }

    // Add item to grid
    public void addItem(int row, int col, GridItem item) {
        if (row < rows && col < cols) {
            grid[row][col] = item;
        }
    }

    // Search item by ID
    public void searchItem(String itemId) {

        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols; j++) {

                if (grid[i][j] != null &&
                        grid[i][j].getItemId().equals(itemId)) {

                    System.out.println("Item Found!");
                    System.out.println("Row: " + i);
                    System.out.println("Column: " + j);
                    System.out.println("Details: " + grid[i][j]);

                    return;
                }
            }
        }

        System.out.println("Item not found in warehouse.");
    }

    // Display warehouse grid
    public void displayGrid() {

        System.out.println("\nWarehouse Grid:");

        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols; j++) {

                if (grid[i][j] != null) {
                    System.out.print("[" + grid[i][j].getItemId() + "] ");
                } else {
                    System.out.print("[Empty] ");
                }
            }
            System.out.println();
        }
    }
}